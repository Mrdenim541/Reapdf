@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
"%~dp0runtime\python.exe" -I "%~dp0app\launcher.py" --desktop
if errorlevel 1 pause
